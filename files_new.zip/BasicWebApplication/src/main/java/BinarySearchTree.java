

public class BinarySearchTree<E extends Comparable<E>> {
	private TreeNode<E> root;
	private boolean addSuccessful;
	private E objectBeingAdded;
	private int size = 0;
	
	public BinarySearchTree() {
		root = null;
	}
	
	public TreeNode<E> getRoot(){
		return root;
	}
	
	public int getSize() {
		return size;
	}

	
	public boolean add(E toInsert) {
		addSuccessful = false;
		objectBeingAdded = toInsert;
		root = add(root);
		return addSuccessful;
	}
	
	
	private TreeNode<E> add(TreeNode<E> currentRoot){
		if(currentRoot == null) {
			addSuccessful = true;
			size++;
			return new TreeNode<E>(objectBeingAdded);
		}
		int compareResult = objectBeingAdded.compareTo(currentRoot.getData());
		if(compareResult < 0) {
			currentRoot.setLeft( add(currentRoot.getLeft()) );
		}else if (compareResult > 0 ) {
			currentRoot.setRight( add(currentRoot.getRight()) );
		}
		return currentRoot;
	}
	public E search(E findMe) {
		   return search(root, findMe);
		}

		private E search(TreeNode<E> currentRoot, E findMe) {
		  if(currentRoot == null) {
		     return null;
		  }// object not in tree
		  if(findMe.equals(currentRoot.getData())) {
		     return currentRoot.getData();
		  }// found the object
		  if(findMe.compareTo(currentRoot.getData()) < 0) {
		     return search(currentRoot.getLeft(), findMe);
		  }
		  return search(currentRoot.getRight(), findMe);
		}
	
	
}
