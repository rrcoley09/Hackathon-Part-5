

public class Username implements Comparable<Username> {
	
	private String username;

	public Username(String theUserName) {
		username = theUserName;
	}


	public String getUsername() {
		return username;
	}
	
	public void setUsername(String theUserName) {
		username = theUserName;
	}
	
	
	public String toString() {	
		return username;
	}


	@Override
	public int compareTo(Username o) {
		// TODO Auto-generated method stub
		return 0;
	}
		

}