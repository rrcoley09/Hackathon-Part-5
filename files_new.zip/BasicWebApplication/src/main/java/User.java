

import java.io.File;
import java.io.Serializable;

public class User implements Comparable<User>, Serializable {
	
	private Username username;
	private String password;

	public User(Username theUserName,String thePassword ) {
		username = theUserName;
		password = thePassword;		
	}
	
	@Override
	public String toString() {
		return username.toString();
	}

	@Override
	public int compareTo(User object) {
		
		return this.getUsername().compareTo(object.getUsername());
		
	}


	public Username getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}

}