

public class TreeNode<E> {

	private E myData;
	private TreeNode<E> left;
	private TreeNode<E> right;	
	
	public TreeNode(E data) {
		myData = data;
		left = null;
		right = null;
	}
	
	public void setLeft(TreeNode<E> newLeft) {
		left = newLeft;
	}
	
	public E getData() {
		return myData;
	}
	
	public TreeNode<E> getLeft(){
		return left;
	}
	public TreeNode<E> getRight(){
		return right;
	}
	public void setRight(TreeNode<E> newRight) {
		right = newRight;
	}
	public void setMyData(E theNewData) {
		myData = theNewData;
	}

}

