
import java.applet.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class signIN extends JFrame{

	private JLabel instructionsL;
	private JComboBox<User> userCB;
	private JButton playB;
	private Container myCP;

	private User currentUser, found;
	private String errorMsg;
	private JLabel passWord;
	private JLabel userName;
	private JButton enterB;
	private JLabel password;
	private JTextField userNameTF;
	private JTextField passWordTF;
	private JLabel promptReturningUser;
	private BinarySearchTree<User> userTree;
	private boolean buttonPressed;
	
	public signIN (BinarySearchTree<User> theUserTree) {
		super("User Authentication");
		doSignIN(theUserTree);
	}
	
	private class MyActionListener implements ActionListener{
		@Override
		public void actionPerformed (ActionEvent e) {
		// TODO Auto-generated method stub
			buttonPressed = true;
		//System.out.print n("BUTTON PRESSED BROOOO");
		}
	}
	
	public void doSignIN (BinarySearchTree<User> theUserTree) {
//			super("User Authentication");
			setSize(500, 500);
			setLocation(100,100);
			myCP = getContentPane();
			myCP.setLayout(new FlowLayout());
			
			userTree = theUserTree;
			
			instructionsL = new JLabel("Sign-Up ");
			instructionsL.setFont(new Font("Arial", Font.PLAIN, 90));
			myCP.add(instructionsL);

			userName = new JLabel("Username: ");
			userName.setFont(new Font("Arial", Font.PLAIN, 29));
			myCP.add(userName);
			
			userNameTF = new JTextField(15);
			userNameTF.setFont(new Font("Arial", Font.PLAIN, 20));
			userNameTF.setText("");
			myCP.add(userNameTF);

			passWord = new JLabel("Password: ");
			passWord.setFont(new Font("Arial", Font.PLAIN, 30));
			myCP.add(passWord);
		
			passWordTF = new JTextField(15);
			passWordTF.setFont(new Font("Arial", Font.PLAIN, 20));
			passWordTF.setText("");
			myCP.add(passWordTF);
			
			

			enterB = new JButton("Enter");
			enterB.setPreferredSize(new Dimension(100, 50));
			enterB.setFont(new Font("Arial", Font.PLAIN, 30));
			//enterB.setBounds(60, 500, 500, 50);
			enterB.addActionListener(new EnterBHandler());
			myCP.add(enterB);

			promptReturningUser = new JLabel("Already a user?");
			promptReturningUser.setFont(new Font("Arial", Font.PLAIN, 10));
			promptReturningUser.setBounds(60, 500, 500, 50);
			myCP.add(promptReturningUser);

			playB = new JButton("Log-in");
			playB.setPreferredSize(new Dimension(75,50));
			playB.setFont(new Font("Times", Font.ROMAN_BASELINE, 10));
			playB.addActionListener(new EnterBHandler());
			myCP.add(playB);

			
			setVisible(true);
			/*addWindowListener(new WindowAdapter()){
				public void windowClosing(WindowEvent e){
					System.exit(0);
				}
			}*/
			
			
		}
		public JComboBox<User> SelectedItem(){
			return userCB;
		}
		
		// You will also need to add a getSize() and getRoot() method
		// to your BinaryTree class.
		private User[] getArray() {
			User[] array = new User[userTree.getSize()];
			getArray(userTree.getRoot(), array, 0);
			return array;
		}

		// TASK 2: REWRITE PRIVATE GETARRAY() METHOD BELOW
		
		// This helper method adds the binary tree items to the array
		// while doing a *preorder traversal* of the tree.
		// You can use it as a model, but your goal is to do 
		// an *inorder traversal* here instead, which will put all the 
		// tree items into the array in sorted order.
		// You will know your method works when you run this GUI and 
		// the dropdown menu shows the Artists names **in alphabeticl order**.
		// Note that your compareTo() in the Name and Artist classes must also
		// be correct for this to work.
		

		private int getArray(TreeNode<User> currentRoot, User[] array, int index) {
			int new_index = index;
			if(currentRoot != null) {
				new_index = getArray(currentRoot.getLeft(), array, new_index);
				array[new_index] = currentRoot.getData();
				new_index++;
				new_index = getArray(currentRoot.getRight(), array, new_index);
			}
			return new_index;
		}

	private void clearInputFields() {
		passWordTF.setText("");
		userNameTF.setText("");
	}
	
	private void adjustButtons(boolean tFValue) {
		enterB.setEnabled(tFValue);
		playB.setEnabled(tFValue);
	}
		
	private void reset() {
		adjustButtons(true);
		clearInputFields();
	}
	
	private JLabel getUserInputName(JTextField theTF, String theText) {
		String userInput = theTF.getText();
		if(userInput.equals("")) {
			errorMsg += "You need to enter a " + theText + "\n";
		}
		JLabel user = new JLabel(userInput);
		return user;
	}
	private boolean validInput() {
		errorMsg = "";
		userName = getUserInputName(userNameTF, "username.");
		passWord = getUserInputName(passWordTF, "password");
		return errorMsg.equals("");
	}


	public void buildPopUp(String text, String userMsg) {
		Frame frame = new Frame (text);
		JButton contButton = new JButton (userMsg);
		contButton.setBounds(100,200,200,100);

		frame. add (contButton);
		frame.setSize(400, 400) ;
		contButton. addActionListener(new MyActionListener());
		frame.setLayout(null);
		frame.setVisible(true);
		buttonPressed = false;
	}

	public class EnterBHandler implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			if(validInput()) {
				currentUser = new User(new Username(userName.toString()), passWord.toString());
				found = userTree.search(currentUser);
				System.out.println(found);
				if (found != null) {
					//duplicateRecord = true;
					adjustButtons(false);
					userNameTF.setText("\nUsername" + found.toString() + "already exists.\n" 
					+ "Pick a new one.\n");
				}else {
					if(userTree.add(currentUser)){
						buildPopUp("\nUser" + currentUser + "added.\n", "press to continue :)\n");
					}else {
						buildPopUp("\nUser" + currentUser + "failed to add.\n", "Retry.");
						signIN myApp = new signIN(userTree);
					}
				}
				clearInputFields();
			}else {
				buildPopUp("\nInvalid Input\n", "Retry");
				signIN myApp = new signIN(userTree);
			}
		}
	}


}