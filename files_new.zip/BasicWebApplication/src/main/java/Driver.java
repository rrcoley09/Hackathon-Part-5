

public class Driver {

	public static void main(String[] args) {
		
		BinarySearchTree bst = new BinarySearchTree();
		signIN popUp = new signIN(bst);
		

	}

}
